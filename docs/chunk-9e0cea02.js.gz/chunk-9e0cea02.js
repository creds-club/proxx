define("./chunk-9e0cea02.js",["exports"],function(e){"use strict";var n=!1,r=performance.now();e.freeze=function(){n=!0},e.getTime=function(){return n||(r=performance.now()),r},e.unfreeze=function(){n=!1}});
//# sourceMappingURL=chunk-9e0cea02.js.map
