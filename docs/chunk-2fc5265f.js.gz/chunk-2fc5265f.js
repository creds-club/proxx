define("./chunk-2fc5265f.js",["exports"],function(t){"use strict";var e=[];t.getCanvas=function(t){if(e.length>0){var n=e.shift();if(n.getContext(t))return n}var r=document.createElement("canvas");return r.setAttribute("aria-hidden","true"),r},t.putCanvas=function(t){e.push(t)}});
//# sourceMappingURL=chunk-2fc5265f.js.map
