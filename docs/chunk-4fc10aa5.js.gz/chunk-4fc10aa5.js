define("./chunk-4fc10aa5.js",["exports"],function(e){"use strict";e.bind=function(e,n,t){return{get:function(){var e=t.value.bind(this);return Object.defineProperty(this,n,{value:e}),e}}}});
//# sourceMappingURL=chunk-4fc10aa5.js.map
